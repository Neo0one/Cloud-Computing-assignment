function ClientMsgSend(){
	var clientmsg = $("#clientmsg").val();
	var apigClient = apigClientFactory.newClient();
	var clientmsg_dics = {};
	var clientmsg_arr = [];
	var clientmsg_dic = {};
	clientmsg_dic["type"] = "string";
	clientmsg_dic["unstructured"] = {};
	clientmsg_dic["unstructured"]["id"] = "123";
	clientmsg_dic["unstructured"]["text"] = clientmsg;
	clientmsg_dic["unstructured"]["timestamp"] = new Date().getTime();
	clientmsg_arr.push(clientmsg_dic);
	clientmsg_dics["messages"] = clientmsg_arr;
	console.log(clientmsg_dics)
	apigClient.chatbotPost(undefined, clientmsg_dics, undefined)
    .then(function(result){
        //This is where you would put a success callback
		console.log(result);
		//document.getElementById('rbtresponse').innerText=JSON.stringify(result.data.messages.unstructured.text);
		document.getElementById('rbtresponse').innerText=result.data.messages[0].unstructured.timestamp + " " + result.data.messages[0].unstructured.text;
    }).catch( function(result){
        //This is where you would put an error callback
		console.log(result);
		document.getElementById('rbtresponse').innerText="YAHAHA";
    });
	
	
	//document.getElementById('rbtresponse').innerText=JSON.stringify(clientmsg_dics);
	//document.getElementById('rbtresponse').innerText=clientmsg;
	}
	
function ShowConversation(){
	$("#chatbot").show();
}

